function love.conf(t)
    t.window.width = 1280
    t.window.height = 720
    t.console = false
    t.window.highdpi = false
end