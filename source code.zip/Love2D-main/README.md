simple pet management software written in lua and has primitive OOP principles. has no use yet whatsoever, only for simlutory use. In future, could potentially be implemented a feature to save pets that are on the dashboard. I know, having everything run is horrible, but it was a project that I was rushing on finishing for my assignment.

!! How to run it !!

1. Download files and put them in a folder
2. Open main.lua file from the folder in visual studio code
3. Download Love2D zip file and extract it
4. Install Love2D support extension on visual studio code
5. While having the main.lua file open in visual studio code, open the extracted folder with Love2D contents in visual studio code
6. Press alt + L and run the main.lua
